import { create } from 'zustand';

export type ViewType =
  | 'dashboard'
  | 'financial-reports'
  | 'students'
  | 'teachers'
  | 'payments'
  | 'teacher-payments'
  | 'schedule'
  | 'services'
  | 'classrooms'
  | 'settings'
  | 'user-management';

export type UserRole = 'ADMIN' | 'SECRETARY';

export interface UserInfo {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
}

export type Lang = 'ar' | 'fr';

interface AppState {
  // Navigation
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;

  // Language
  lang: Lang;
  setLang: (lang: Lang) => void;
  toggleLang: () => void;

  // Auth
  user: UserInfo | null;
  setUser: (user: UserInfo | null) => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

export const useAppStore = create<AppState>((set) => ({
  currentView: 'dashboard',
  setCurrentView: (view) => set({ currentView: view }),
  lang: 'ar',
  setLang: (lang) => set({ lang }),
  toggleLang: () =>
    set((state) => ({ lang: state.lang === 'ar' ? 'fr' : 'ar' })),
  user: null,
  setUser: (user) =>
    set({
      user,
      isAuthenticated: !!user,
      isAdmin: user?.role === 'ADMIN',
    }),
  isAuthenticated: false,
  isAdmin: false,
}));

// Views restricted to ADMIN only
export const ADMIN_ONLY_VIEWS: ViewType[] = ['financial-reports', 'user-management'];

// All navigation keys
export const NAV_KEYS: ViewType[] = [
  'dashboard', 'financial-reports', 'students', 'teachers', 'payments',
  'teacher-payments', 'schedule', 'services', 'classrooms', 'user-management', 'settings',
];
