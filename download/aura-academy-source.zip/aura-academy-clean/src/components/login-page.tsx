'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Lock } from 'lucide-react';
import { useAppStore } from '@/store/store';

export function LoginPage() {
  const { lang, setUser, setLang } = useAppStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const isAr = lang === 'ar';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || (isAr ? 'حدث خطأ' : 'Erreur'));
        return;
      }

      setUser(data.user);
    } catch {
      setError(isAr ? 'خطأ في الاتصال بالخادم' : 'Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-white to-teal-50 p-4" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Language Toggle */}
      <div className="absolute top-4 right-4 lg:top-6 lg:right-6">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setLang(isAr ? 'fr' : 'ar')}
          className="gap-1.5 h-8 px-3 text-xs font-medium bg-white/80 backdrop-blur-sm border-gray-200"
        >
          {isAr ? 'Français' : 'عربي'}
        </Button>
      </div>

      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-600 text-white font-bold text-2xl shadow-lg mb-4">
            A
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Aura Academy</h1>
          <p className="text-sm text-gray-500 mt-1">
            {isAr ? 'نظام إدارة المركز التربوي' : 'Système de gestion du centre'}
          </p>
        </div>

        {/* Login Card */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto mb-2 w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
              <Lock className="h-6 w-6 text-emerald-600" />
            </div>
            <CardTitle className="text-xl">
              {isAr ? 'تسجيل الدخول' : 'Connexion'}
            </CardTitle>
            <CardDescription>
              {isAr ? 'أدخل بياناتك للوصول إلى النظام' : 'Entrez vos identifiants pour accéder au système'}
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive" className="border-0 bg-red-50 text-red-700">
                  <AlertDescription className="text-sm">{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                  {isAr ? 'البريد الإلكتروني' : 'Email'}
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={isAr ? 'example@email.com' : 'example@email.com'}
                  required
                  className="h-11 border-gray-200 focus:border-emerald-500 focus:ring-emerald-500/20"
                  dir="ltr"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                  {isAr ? 'كلمة المرور' : 'Mot de passe'}
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="h-11 border-gray-200 focus:border-emerald-500 focus:ring-emerald-500/20"
                  dir="ltr"
                />
              </div>

              <Button
                type="submit"
                disabled={loading || !email || !password}
                className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-sm cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin me-2" />
                    {isAr ? 'جاري الدخول...' : 'Connexion...'}
                  </>
                ) : (
                  isAr ? 'دخول' : 'Se connecter'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-gray-400 mt-6">
          © {new Date().getFullYear()} Aura Academy — {isAr ? 'بني ملال، المغرب' : 'Béni Mellal, Maroc'}
        </p>
      </div>
    </div>
  );
}
