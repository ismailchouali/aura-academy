import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/session';

const MONTH_ORDER = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const MONTH_LABELS: Record<string, string> = {
  January: 'يناير', February: 'فبراير', March: 'مارس', April: 'أبريل',
  May: 'ماي', June: 'يونيو', July: 'يوليوز', August: 'غشت',
  September: 'شتنبر', October: 'أكتوبر', November: 'نونبر', December: 'دجنبر',
};

function getMonthIndex(month: string): number {
  return MONTH_ORDER.indexOf(month);
}

function countMonthsOverdue(
  month: string,
  year: number,
  packMonths?: number | null,
  isLangues?: boolean,
  paymentDate?: Date | string | null
): number {
  const now = new Date();
  const curYear = now.getFullYear();
  const curMonth = now.getMonth(); // 0-indexed
  const currentYM = curYear * 12 + curMonth;

  // For Langues service with a pack, use paymentDate to calculate months since payment
  if (isLangues && packMonths && packMonths > 1 && paymentDate) {
    const pDate = new Date(paymentDate);
    const payYear = pDate.getFullYear();
    const payMonth = pDate.getMonth(); // 0-indexed
    const paymentYM = payYear * 12 + payMonth;
    const monthsSincePayment = Math.max(0, currentYM - paymentYM);
    // The pack covers (packMonths - 1) additional months beyond the first
    return Math.max(0, monthsSincePayment - (packMonths - 1));
  }

  // Default: use month/year fields
  const mIdx = getMonthIndex(month);
  const paymentYM = year * 12 + mIdx;
  const rawOverdue = Math.max(0, currentYM - paymentYM);
  return rawOverdue;
}

function isOverdue(month: string, year: number, packMonths?: number | null, isLangues?: boolean, paymentDate?: Date | string | null): boolean {
  return countMonthsOverdue(month, year, packMonths, isLangues, paymentDate) >= 1;
}

export async function GET(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof NextResponse) return auth;

  try {
    // Fetch all payments with remaining amount > 0
    const payments = await db.payment.findMany({
      where: {
        remainingAmount: { gt: 0 },
      },
      include: {
        student: {
          include: {
            level: {
              include: {
                subject: { include: { service: true } },
              },
            },
            teacher: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Filter to only overdue payments, checking packMonths for Langues
    const overduePayments = payments.filter((p) => {
      const serviceId = p.student.level?.subject?.service?.id || '';
      const isLangues = serviceId === 'service_langues';
      return isOverdue(p.month, p.year, p.packMonths, isLangues, p.paymentDate);
    });

    // Group by service → level → student
    const serviceMap = new Map<string, Map<string, Map<string, typeof overduePayments>>>();

    for (const p of overduePayments) {
      const serviceName = p.student.level?.subject?.service?.nameAr || 'بدون خدمة';
      const levelName = p.student.level?.nameAr || 'بدون مستوى';
      const studentKey = p.studentId;

      if (!serviceMap.has(serviceName)) serviceMap.set(serviceName, new Map());
      const levelMap = serviceMap.get(serviceName)!;
      if (!levelMap.has(levelName)) levelMap.set(levelName, new Map());
      const studentMap = levelMap.get(levelName)!;
      if (!studentMap.has(studentKey)) studentMap.set(studentKey, []);
      studentMap.get(studentKey)!.push(p);
    }

    // Build response
    const result = Array.from(serviceMap.entries()).map(([service, levelMap]) => {
      const levels = Array.from(levelMap.entries()).map(([level, studentMap]) => {
        const students = Array.from(studentMap.entries()).map(([, payments]) => {
          const student = payments[0].student;
          const totalOverdue = payments.reduce((s, p) => s + p.remainingAmount, 0);
          const maxMonthsOverdue = Math.max(
            ...payments.map((p) => {
              const serviceId = p.student.level?.subject?.service?.id || '';
              const isLangues = serviceId === 'service_langues';
              return countMonthsOverdue(p.month, p.year, p.packMonths, isLangues, p.paymentDate);
            })
          );

          return {
            studentId: student.id,
            studentName: student.fullName,
            phone: student.phone || null,
            parentPhone: student.parentPhone || null,
            parentName: student.parentName || null,
            monthlyFee: student.monthlyFee,
            totalOverdue,
            monthsOverdue: maxMonthsOverdue,
            paymentCount: payments.length,
            overduePayments: payments.map((p) => {
              const serviceId = p.student.level?.subject?.service?.id || '';
              const isLangues = serviceId === 'service_langues';
              return {
                id: p.id,
                month: p.month,
                monthLabel: MONTH_LABELS[p.month] || p.month,
                year: p.year,
                remainingAmount: p.remainingAmount,
                monthsOverdue: countMonthsOverdue(p.month, p.year, p.packMonths, isLangues, p.paymentDate),
              };
            }),
          };
        });

        const totalLevelOverdue = students.reduce((s, st) => s + st.totalOverdue, 0);

        return {
          level,
          students,
          totalOverdue: totalLevelOverdue,
          studentCount: students.length,
        };
      });

      const totalServiceOverdue = levels.reduce((s, l) => s + l.totalOverdue, 0);
      const totalStudentCount = levels.reduce((s, l) => s + l.studentCount, 0);

      return {
        service,
        levels,
        totalOverdue: totalServiceOverdue,
        studentCount: totalStudentCount,
      };
    });

    // Sort services by total overdue (descending)
    result.sort((a, b) => b.totalOverdue - a.totalOverdue);

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error fetching overdue payments:', error);
    return NextResponse.json(
      { error: 'Failed to fetch overdue payments' },
      { status: 500 }
    );
  }
}
