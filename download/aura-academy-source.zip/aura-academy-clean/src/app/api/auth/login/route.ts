import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyPassword, generateSessionToken, createSessionExpiry } from '@/lib/auth';
import { rateLimit } from '@/lib/rate-limit';
import { sanitizeEmail, isValidEmail, isValidPassword, sanitizeString } from '@/lib/validate';

export async function POST(request: NextRequest) {
  try {
    // Rate limiting by IP
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const limiter = rateLimit(`login:${ip}`, { maxAttempts: 10, windowMs: 15 * 60 * 1000 });

    if (!limiter.success) {
      return NextResponse.json(
        { error: 'محاولات كثيرة. حاول بعد قليل', code: 'RATE_LIMITED', resetIn: Math.ceil(limiter.resetIn / 1000) },
        { status: 429 }
      );
    }

    const body = await request.json();
    const email = sanitizeEmail(body.email);
    const password = body.password;

    if (!email || !password) {
      return NextResponse.json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبان' }, { status: 400 });
    }

    if (!isValidEmail(email)) {
      return NextResponse.json({ error: 'بريد إلكتروني غير صالح' }, { status: 400 });
    }

    if (!isValidPassword(password)) {
      return NextResponse.json({ error: 'كلمة المرور غير صالحة' }, { status: 400 });
    }

    const user = await db.user.findUnique({ where: { email } });
    if (!user || user.status !== 'active') {
      return NextResponse.json({ error: 'بيانات الدخول غير صحيحة' }, { status: 401 });
    }

    const isValid = await verifyPassword(password, user.password);
    if (!isValid) {
      return NextResponse.json({ error: 'بيانات الدخول غير صحيحة' }, { status: 401 });
    }

    // Clean up old sessions for this user (keep max 3 sessions)
    const existingSessions = await db.session.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
    });
    if (existingSessions.length > 3) {
      const toDelete = existingSessions.slice(3);
      await db.session.deleteMany({
        where: { id: { in: toDelete.map(s => s.id) } },
      }).catch(() => {});
    }

    // Create session
    const token = generateSessionToken();
    const expiresAt = createSessionExpiry(168); // 7 days

    await db.session.create({
      data: {
        token,
        userId: user.id,
        expiresAt,
      },
    });

    const response = NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
      },
    });

    // Secure cookie settings
    response.cookies.set('aura_session', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60, // 7 days
      path: '/',
      // partitioned: true, // For production if needed
    });

    return response;
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء تسجيل الدخول' }, { status: 500 });
  }
}
