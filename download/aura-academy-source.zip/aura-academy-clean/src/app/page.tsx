'use client';

import { useAppStore, ViewType, NAV_KEYS, ADMIN_ONLY_VIEWS } from '@/store/store';
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useT } from '@/hooks/use-translation';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  LayoutDashboard,
  TrendingUp,
  Users,
  GraduationCap,
  Receipt,
  Wallet,
  CalendarDays,
  BookOpen,
  DoorOpen,
  Settings,
  Shield,
  Menu,
  Phone,
  MapPin,
  Globe,
  LogOut,
  Loader2,
} from 'lucide-react';
import { LoginPage } from '@/components/login-page';
import { FinancialReportsView } from '@/components/views/financial-reports-view';
import { DashboardView } from '@/components/views/dashboard-view';
import { StudentsView } from '@/components/views/students-view';
import { TeachersView } from '@/components/views/teachers-view';
import { PaymentsView } from '@/components/views/payments-view';
import { TeacherPaymentsView } from '@/components/views/teacher-payments-view';
import { ScheduleView } from '@/components/views/schedule-view';
import { ServicesView } from '@/components/views/services-view';
import { ClassroomsView } from '@/components/views/classrooms-view';
import { SettingsView } from '@/components/views/settings-view';
import { UserManagementView } from '@/components/views/user-management-view';
import { ErrorBoundary } from '@/components/error-boundary';

const navIcons: Record<ViewType, React.ReactNode> = {
  dashboard: <LayoutDashboard className="h-5 w-5" />,
  'financial-reports': <TrendingUp className="h-5 w-5" />,
  students: <Users className="h-5 w-5" />,
  teachers: <GraduationCap className="h-5 w-5" />,
  payments: <Receipt className="h-5 w-5" />,
  'teacher-payments': <Wallet className="h-5 w-5" />,
  schedule: <CalendarDays className="h-5 w-5" />,
  services: <BookOpen className="h-5 w-5" />,
  classrooms: <DoorOpen className="h-5 w-5" />,
  settings: <Settings className="h-5 w-5" />,
  'user-management': <Shield className="h-5 w-5" />,
};

function getNavLabel(t: ReturnType<typeof useT>, id: ViewType): string {
  const map: Record<ViewType, string> = {
    dashboard: t.nav.dashboard,
    'financial-reports': t.nav.financialReports,
    students: t.nav.students,
    teachers: t.nav.teachers,
    payments: t.nav.payments,
    'teacher-payments': t.nav.teacherPayments,
    schedule: t.nav.schedule,
    services: t.nav.services,
    classrooms: t.nav.classrooms,
    settings: t.nav.settings,
    'user-management': t.nav?.userManagement || 'إدارة الحسابات',
  };
  return map[id] || id;
}

function getNavDesc(t: ReturnType<typeof useT>, id: ViewType): string {
  if (id === 'dashboard') return t.nav.dashboardDesc;
  if (id === 'financial-reports') return t.nav.financialReportsDesc;
  if (id === 'user-management') return t.nav?.userManagementDesc || 'إدارة حسابات المستخدمين';
  return `${t.nav.manageDashboard.replace(t.nav.dashboard, '')} ${getNavLabel(t, id)}`;
}

function SidebarContent({ currentView, onNavigate, onMobileClose }: { currentView: ViewType; onNavigate: (v: ViewType) => void; onMobileClose?: () => void }) {
  const t = useT();
  const { user, isAdmin, lang } = useAppStore();

  // Filter navigation items based on role
  const visibleNavKeys = NAV_KEYS.filter((id) => {
    if (ADMIN_ONLY_VIEWS.includes(id) && !isAdmin) return false;
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="p-5 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sidebar-primary flex items-center justify-center text-sidebar-primary-foreground font-bold text-lg shadow-lg">
            A
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">Aura Academy</h1>
            <p className="text-xs text-sidebar-foreground/70">{t.sidebar.systemName}</p>
          </div>
        </div>
      </div>

      <Separator className="bg-sidebar-border" />

      {/* Navigation */}
      <ScrollArea className="flex-1 py-3 px-2">
        <nav className="space-y-1">
          {visibleNavKeys.map((id) => (
            <Button
              key={id}
              variant="ghost"
              onClick={() => {
                onNavigate(id);
                onMobileClose?.();
              }}
              className={cn(
                'w-full justify-start gap-3 h-11 px-3 font-medium transition-all duration-200',
                currentView === id
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-md hover:bg-sidebar-primary/90'
                  : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              )}
            >
              {navIcons[id]}
              <span>{getNavLabel(t, id)}</span>
            </Button>
          ))}
        </nav>
      </ScrollArea>

      <Separator className="bg-sidebar-border" />

      {/* User Info */}
      <div className="p-4 space-y-2">
        <div className="flex items-center gap-2 text-xs text-sidebar-foreground/70">
          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white font-bold text-xs shrink-0 ${isAdmin ? 'bg-emerald-600' : 'bg-blue-500'}`}>
            {user?.fullName?.charAt(0) || '?'}
          </div>
          <div className="min-w-0">
            <p className="font-medium text-xs text-sidebar-foreground truncate">{user?.fullName || ''}</p>
            <p className="truncate" dir="ltr">{user?.email || ''}</p>
          </div>
        </div>
      </div>

      <Separator className="bg-sidebar-border" />

      {/* Center Info */}
      <div className="p-4 space-y-2 text-xs text-sidebar-foreground/70">
        <div className="flex items-center gap-2">
          <Phone className="h-3.5 w-3.5 shrink-0" />
          <span dir="ltr">0606030356</span>
        </div>
        <div className="flex items-start gap-2">
          <MapPin className="h-3.5 w-3.5 shrink-0 mt-0.5" />
          <span className="line-clamp-2">بني ملال، شارع محمد الخامس، فوق مكتبة وورك بيرو</span>
        </div>
      </div>
    </div>
  );
}

function LanguageToggle() {
  const { lang, toggleLang } = useAppStore();

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={toggleLang}
      className="gap-1.5 h-8 px-3 text-xs font-medium"
    >
      <Globe className="h-3.5 w-3.5" />
      {lang === 'ar' ? 'عربي' : 'Français'}
    </Button>
  );
}

function AuthLoadingScreen() {
  return (
    <div className="flex items-center justify-center h-screen bg-white">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-600 mx-auto mb-4" />
        <p className="text-muted-foreground text-sm">...</p>
      </div>
    </div>
  );
}

export default function Home() {
  const { currentView, setCurrentView, lang, user, isAuthenticated, isAdmin, setUser } = useAppStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const t = useT();
  const [authChecking, setAuthChecking] = useState(true);

  // Check session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await fetch('/api/auth/me');
        const data = await res.json();
        if (data.user) {
          setUser(data.user);
        }
      } catch {
        // Session check failed
      } finally {
        setAuthChecking(false);
      }
    };
    checkSession();
  }, [setUser]);

  // Show login page if not authenticated
  if (authChecking) return <AuthLoadingScreen />;
  if (!isAuthenticated) return <LoginPage />;

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <DashboardView onNavigate={setCurrentView} />;
      case 'financial-reports': return <FinancialReportsView />;
      case 'students': return <StudentsView />;
      case 'teachers': return <TeachersView />;
      case 'payments': return <PaymentsView />;
      case 'teacher-payments': return <TeacherPaymentsView />;
      case 'schedule': return <ScheduleView />;
      case 'services': return <ServicesView />;
      case 'classrooms': return <ClassroomsView />;
      case 'settings': return <SettingsView />;
      case 'user-management': return isAdmin ? <UserManagementView /> : null;
      default: return <DashboardView onNavigate={setCurrentView} />;
    }
  };

  // RTL/LTR direction based on language
  const dir = lang === 'ar' ? 'rtl' : 'ltr';

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // Ignore logout errors
    }
    setUser(null);
    setCurrentView('dashboard');
  };

  return (
    <div className="flex h-screen overflow-hidden bg-bg-main" dir={dir}>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 shadow-xl">
        <SidebarContent currentView={currentView} onNavigate={setCurrentView} />
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar (Mobile) */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-white border-b sticky top-0 z-40">
          <div className="flex items-center gap-3">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="shrink-0">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side={lang === 'ar' ? 'right' : 'left'} className="w-64 p-0">
                <SheetTitle className="sr-only">{t.sidebar.menuTitle}</SheetTitle>
                <SidebarContent
                  currentView={currentView}
                  onNavigate={setCurrentView}
                  onMobileClose={() => setMobileOpen(false)}
                />
              </SheetContent>
            </Sheet>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">A</div>
              <h1 className="font-bold text-primary">Aura Academy</h1>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogout}
            className="text-gray-500 hover:text-red-600"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </header>

        {/* Desktop Header */}
        <header className="hidden lg:flex items-center justify-between px-6 py-3 bg-white border-b">
          <div>
            <h2 className="text-lg font-bold text-foreground">
              {getNavLabel(t, currentView)}
            </h2>
            <p className="text-xs text-muted-foreground">
              {getNavDesc(t, currentView)}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <LanguageToggle />
            {/* User Info */}
            <div className="flex items-center gap-2">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm ${isAdmin ? 'bg-emerald-600' : 'bg-blue-500'}`}>
                {user?.fullName?.charAt(0) || '?'}
              </div>
              <div className="hidden xl:block">
                <p className="text-sm font-medium text-foreground leading-tight">{user?.fullName}</p>
                <p className="text-xs text-muted-foreground">
                  {isAdmin
                    ? (lang === 'ar' ? 'مدير' : 'Admin')
                    : (lang === 'ar' ? 'سكرتير' : 'Secrétaire')
                  }
                </p>
              </div>
            </div>
            {/* Logout Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="gap-1.5 h-8 px-3 text-xs font-medium text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200 cursor-pointer"
            >
              <LogOut className="h-3.5 w-3.5" />
              {lang === 'ar' ? 'خروج' : 'Déconnexion'}
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6">
          <div className="max-w-7xl mx-auto">
            <ErrorBoundary>
              {renderView()}
            </ErrorBoundary>
          </div>
        </div>
      </main>
    </div>
  );
}
