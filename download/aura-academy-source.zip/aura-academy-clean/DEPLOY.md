# Aura Academy - Guide de Deploiement

## ⚠️ IMPORTANT: Netlify NE SUPPORTE PAS cette application

Cette application utilise **SQLite** (base de donnees fichier) et **Next.js avec API Routes**.
Netlify utilise des "serverless functions" qui ont un systeme de fichiers ephemere —
les donnees seront perdues a chaque appel d'API.

### ✅ Options de Deploiement Recommandees:

---

## Option 1: Railway.app (Le plus facile — GRATUIT)

Railway supporte Node.js + SQLite directement. C'est la meilleure option.

### Etapes:
1. Allez sur https://railway.app et creez un compte
2. Cliquez "New Project" → "Deploy from GitHub repo"
3. Connectez votre repo GitHub qui contient le code
4. Railway va detecter automatiquement Next.js
5. Ajoutez ces variables d'environnement dans Railway:
   - `DATABASE_URL` = `file:./db/custom.db`
   - `SESSION_SECRET` = une chaine aleatoire (ex: `openssl rand -hex 32`)
6. Railway va builder et deployer automatiquement

### Commandes de build dans Railway:
- Build Command: `npx prisma generate && npx prisma db push && npm run build`
- Start Command: `npm start`

---

## Option 2: Render.com (Gratuit)

Render supporte les serveurs Node.js avec filesystem persistant.

### Etapes:
1. Allez sur https://render.com et creez un compte
2. Cliquez "New" → "Web Service"
3. Connectez votre repo GitHub
4. Configurez:
   - Build Command: `npx prisma generate && npx prisma db push && npm run build`
   - Start Command: `npm start`
   - Environment: `NODE_ENV=production`
5. Ajoutez les variables d'environnement:
   - `DATABASE_URL` = `file:./db/custom.db`
   - `SESSION_SECRET` = une chaine aleatoire
6. Deployez!

### Note: Utilisez un "Persistent Disk" sur Render pour garder la base de donnees.

---

## Option 3: VPS (DigitalOcean, Hostinger, OVH)

Si vous avez un VPS, c'est le plus fiable:

```bash
# 1. Clone le repo
git clone votre-repo.git
cd aura-academy

# 2. Installe les dependances
npm install

# 3. Configure l'environnement
cp .env.example .env
# Edite .env avec vos valeurs

# 4. Initialise la base de donnees
npx prisma generate
npx prisma db push
npx prisma db seed

# 5. Build et lance
npm run build
npm start
```

Utilisez PM2 pour garder le serveur en marche:
```bash
npm install -g pm2
pm2 start npm --name "aura-academy" -- start
pm2 save
pm2 startup
```

---

## Installation Locale (sur votre PC)

```bash
# 1. Extrayez le zip
unzip aura-academy-source.zip
cd aura-academy-deploy

# 2. Installez les dependances
npm install
# ou: bun install

# 3. Configurez
cp .env.example .env

# 4. Initialisez la base de donnees
npx prisma generate
npx prisma db push

# 5. Lancez le serveur
npm run dev
# Allez sur: http://localhost:3000

# Identifiants par defaut:
# Admin: admin / admin123
# Secretaire: secretary / secretary123
```

---

## Structure du Projet

```
aura-academy/
├── src/
│   ├── app/              # Pages et API Routes (Next.js App Router)
│   │   ├── api/          # Toutes les APIs (auth, students, payments, etc.)
│   │   ├── globals.css   # Styles globaux
│   │   ├── layout.tsx    # Layout principal
│   │   └── page.tsx      # Page d'accueil
│   ├── components/       # Composants React
│   │   ├── ui/           # Composants shadcn/ui
│   │   ├── views/        # Vues principales (dashboard, students, etc.)
│   │   ├── login-page.tsx
│   │   └── error-boundary.tsx
│   ├── hooks/            # Hooks React
│   ├── lib/              # Bibliotheques (auth, db, session, etc.)
│   └── store/            # Zustand store
├── prisma/
│   ├── schema.prisma     # Schema de la base de donnees
│   └── seed.ts           # Donnees initiales
├── public/               # Fichiers statiques (logo)
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── next.config.ts
└── .env.example          # Variables d'environnement (a copier en .env)
```

---

## Fonctionnalites

- Gestion des etudiants (CRUD + paiements + forfaits)
- Gestion des professeurs et salaires
- Gestion des salles de classe
- Gestion des forfaits/services
- Planning hebdomadaire
- Tableau de bord avec statistiques
- Rapports financiers
- Gestion des utilisateurs (Admin + Secretaire)
- Systeme de backup/restauration
- Interface bilingue (Francais/Arabe)
- Mode sombre/clair
- Design responsive (mobile + desktop)
